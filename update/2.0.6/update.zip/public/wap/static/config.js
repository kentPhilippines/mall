window.host = '';
window.entId = '';